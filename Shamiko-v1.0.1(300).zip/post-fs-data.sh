MODDIR=${0%/*}
MODULE_MIN_MAGISK_VERSION=26404
MODULE_MIN_KSUD_VERSION=11412
MODULE_MIN_ZYGISKSU_VERSION=178
MAGISK_VERSION="$(magisk -V)"
if [ -z "$MAGISK_VERSION" ]; then
  ZYGISKSU_VERSION=$(grep versionCode < /data/adb/modules/zygisksu/module.prop | sed 's/versionCode=//g')
  if [ "$(/data/adb/ksud -V)" -lt "$MODULE_MIN_KSUD_VERSION" ] || [ -z "$ZYGISKSU_VERSION" ] || [ "$ZYGISKSU_VERSION" -lt "$MODULE_MIN_ZYGISKSU_VERSION" ]; then
   touch "$MODDIR/disable"
  fi
elif [ "$MAGISK_VERSION" -lt "$MODULE_MIN_MAGISK_VERSION" ]; then
  touch "$MODDIR/disable"
fi
